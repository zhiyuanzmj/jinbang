<?php
/*
 * LICENSE:
 * Please provide your Client Area Designer Module For WHMCS license below
 */
$client_area_designer_licensekey="ModulesGarden_ClientAreaDesigner_W_XXXXXXXXXXX";
