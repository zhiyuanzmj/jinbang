$(document).on('ready', function() {
   $(".mg-cad-slick").slick();
});

